package com.automate.farmrise.pageobjects;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.asserts.Assertion;

import com.automate.farmrise.page.HomePage;
import com.automate.farmrise.page.MorePage;

import io.appium.java_client.AppiumDriver;

public class VerifyTumbnailofGovtSchemesPageObject {
	public AppiumDriver driver;
	public final static Logger logger = Logger.getLogger(VerifyWeatherTimingsPageObject.class);	
	public VerifyTumbnailofGovtSchemesPageObject(AppiumDriver driver) {
		this.driver = driver;
	}
	
	/*In the method performing verifing govt scheme thumb nail
	 * Also its a generic function*/
	public void VerifyTumbnailofGovtSchemes() throws Exception {
		try{
			String tcName = Thread.currentThread().getStackTrace()[1].getMethodName();
			Reporter.log("Testcase: "+tcName, true);
			HomePage homePage = new HomePage(getDriver());
			homePage.more_Tab.isDisplayed();
			homePage.more_Tab.click();
			Reporter.log("Step: Successfully clicked on More Tab", true);
			MorePage morePage = new MorePage(getDriver());
			morePage.govtSchemes_Option.isDisplayed();
			morePage.govtSchemes_Option.click();
			Reporter.log("Step: Successfully clicked on Govt schemes option", true);
			morePage.govtSchemeThumbnail.isDisplayed();
			Reporter.log("Step: Successfully verified on Govt schemes thumbnail displayed", true);
			
		}catch(Exception e){
			logger.info("Error occured while verifing Govt schemes thumbnail");
			Reporter.log("Error occured while verifing Govt schemes thumbnail", true);
			throw new Exception("Error occured while verifing Govt schemes thumbnail");
		}

	}
	public AppiumDriver getDriver() {
		return driver;
	}

	public void setDriver(AppiumDriver driver) {
		this.driver = driver;
	}
}
