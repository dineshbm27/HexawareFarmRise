package com.automate.farmrise.page;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.WithTimeout;

public class MorePage {
	public MorePage(AppiumDriver<WebElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	/*Intializing all web elements required */ 
	@WithTimeout(time  = 20, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.climate.farmrise:id/more_govtSchemes")
	public WebElement govtSchemes_Option;
	@WithTimeout(time  = 20, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.climate.farmrise:id/more_settings")
	public WebElement moreSettings_Option;
	@WithTimeout(time  = 20, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.climate.farmrise:id/govtSchemeThumbnail")
	public WebElement govtSchemeThumbnail;
}
