package com.automate.farmrise.test;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.automate.farmrise.appiumwrapper.AppiumBase;
import com.automate.farmrise.appiumwrapper.ExcelSheetLib1;
import com.automate.farmrise.appiumwrapper.Genericclass;
import com.automate.farmrise.pageobjects.VerifyTumbnailofGovtSchemesPageObject;
import com.automate.farmrise.pageobjects.VerifyWeatherTimingsPageObject;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.appium.java_client.MobileDriver;

/***
 * <h1>FarmRiseTest</h1>
 * <p>
 * <b>Description:</b> Device related Test cases to verify weather timing and govt scheme thumbnail
 *
 * @author Dinesh B M
 * @version 
 * @since 20/12/2018
 */

public class FarmRiseTest extends AppiumBase{
	ExtentTest logger;
	String userDirPath = System.getProperty("user.dir");	
		
	/***
	 * @TestName toVerifyWeatherTimingsTest
	 * @TestDescription Launching Farm rise app and verify weather Timings
	 */
	@Test(groups={"Positive","Smoke","UAT"})
	  public void toVerifyWeatherTimingsTest() throws Exception 
	  {	
		try{			
			String tcName = Thread.currentThread().getStackTrace()[1].getMethodName();
			logger=extent.startTest("FarmRiseTest-"+tcName+"", "To verify weather timings ");			
			VerifyWeatherTimingsPageObject weather = new VerifyWeatherTimingsPageObject(driver);
		  	weather.verifyTimingofWheather();
		  	logger.log(LogStatus.INFO, "Successfully verified Weather timing");
		  	
		  	
		}catch(Exception e){
				//Taking and atatching screenshot in the report
				logger.log(LogStatus.FAIL, ExceptionUtils.getStackTrace(e));
				Genericclass gen = new Genericclass();
				String img=logger.addScreenCapture(gen.takeSnapShot1((MobileDriver) driver, userDirPath+"/Screenshots/failed.png"));
				logger.log(LogStatus.INFO, "Failure Screenshot Taken",img);
				throw new Exception("Exception : " + e.getMessage());
		}
	  }
	
	/***
	 * @TestName toVerifyTumbnailofGovtSchemesTest
	 * @TestDescription Launching Fram Rise app and verify Govt schemes thumbnail displayed
	 */
	@Test(groups={"Positive","Smoke","UAT"})
	  public void toVerifyTumbnailofGovtSchemesTest() throws Exception 
	  {	
		try{			
			String tcName = Thread.currentThread().getStackTrace()[1].getMethodName();
			logger=extent.startTest("FarmRiseTest-"+tcName+"", "To verify Govt schemes thumnail displayed");
			VerifyTumbnailofGovtSchemesPageObject thumnail = new VerifyTumbnailofGovtSchemesPageObject(driver);
			thumnail.VerifyTumbnailofGovtSchemes();
		  	logger.log(LogStatus.INFO, "Successfully verified on Govt schemes thumbnail displayed");
		  	
		  	
		}catch(Exception e){
				//Taking and atatching screenshot in the report
				logger.log(LogStatus.FAIL, ExceptionUtils.getStackTrace(e));
				Genericclass gen = new Genericclass();
				String img=logger.addScreenCapture(gen.takeSnapShot1((MobileDriver) driver, userDirPath+"/Screenshots/failed.png"));
				logger.log(LogStatus.INFO, "Failure Screenshot Taken",img);
				throw new Exception("Exception : " + e.getMessage());
		}
	  }
	
	//This method is to take failed screenshots after every testcase
	@AfterMethod(alwaysRun=true)
	public void endtest(ITestResult result) throws IOException
		{
			  if(driver!=null)
			  {
				  if(ITestResult.FAILURE==result.getStatus())
				  	{
					  	//Taking screenshots when testcase is failed
					  	TakesScreenshot ts=(TakesScreenshot)driver;	   
					  	File source=ts.getScreenshotAs(OutputType.FILE);	   
					  	FileUtils.copyFile(source, new File("./FailedScreenshots/"+result.getName()+".png"));	
					  	logger.log(LogStatus.INFO, "Successfully taken failed screenshot");
					  	System.out.println("Screenshot taken");
				  	}
		  		 driver.quit();
		  	  extent.endTest(logger);
		  	  extent.flush();
			  }
		  }
}
