package com.automate.farmrise.pageobjects;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.asserts.Assertion;

import com.automate.farmrise.page.HomePage;

import io.appium.java_client.AppiumDriver;

public class VerifyWeatherTimingsPageObject {
	public AppiumDriver driver;
	public final static Logger logger = Logger.getLogger(VerifyWeatherTimingsPageObject.class);	
	public VerifyWeatherTimingsPageObject(AppiumDriver driver) {
		this.driver = driver;
	}
	
	/*In the method performing actions to verify weather timings
	 * Also its a generic function*/
	public void verifyTimingofWheather() throws Exception {
		try{
			String tcName = Thread.currentThread().getStackTrace()[1].getMethodName();
			Reporter.log("Testcase: "+tcName, true);
			HomePage homePage = new HomePage(getDriver());
			homePage.home_Tab.isDisplayed();
			homePage.home_Tab.click();
			Reporter.log("Step: Successfully clicked on Home Tab", true);
			homePage.accessWeatherDetails_Button.isDisplayed();
			homePage.accessWeatherDetails_Button.click();
			Reporter.log("Step: Successfully clicked on Access Weather Details option", true);
			List<WebElement> web = driver.findElementsById("com.climate.farmrise:id/hourlyValue");			
			Assertion asse = new Assertion();
			asse.assertEquals(web.get(0).getText(), "Now");
			Reporter.log("Step: Successfully verified Weather timing", true);
		}catch(Exception e){
			logger.info("Error occured while verify Weather timing");
			Reporter.log("Error occured while verify Weather timing", true);
			throw new Exception("Error occured while verify Weather timing");
		}

	}
	public AppiumDriver getDriver() {
		return driver;
	}

	public void setDriver(AppiumDriver driver) {
		this.driver = driver;
	}
}
