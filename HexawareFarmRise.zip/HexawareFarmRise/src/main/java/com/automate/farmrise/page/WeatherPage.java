package com.automate.farmrise.page;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.WithTimeout;

public class WeatherPage {
	public WeatherPage(AppiumDriver<WebElement> driver)
	{
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	/*Intializing all web elements required */ 
	@WithTimeout(time  = 20, unit = TimeUnit.SECONDS)
	@AndroidFindBy(id = "com.climate.farmrise:id/hourlyValue")
	public WebElement hourlyValue;
}
